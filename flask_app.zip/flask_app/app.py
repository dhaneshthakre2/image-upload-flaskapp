from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import os
from config import Config, allowed_file

app = Flask(__name__)
app.config.from_object(Config)

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            print("No file part in request")
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('No selected file')
            print("No file selected")
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            flash('File successfully uploaded')
            print(f"File uploaded successfully: {filename}")
            return redirect(url_for('display_file', filename=filename))
    
    print("GET request or form not submitted correctly")
    return render_template('upload.html')

@app.route('/display/<filename>')
def display_file(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    print(f"Displaying file: {filename} at {file_path}")
    return render_template('display.html', filename=filename, file_path=file_path)

if __name__ == '__main__':
    app.run(debug=True)
